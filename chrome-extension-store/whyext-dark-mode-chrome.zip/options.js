"use strict";
(() => {
    const STORAGE_KEY = "darkModeDomains";
    function setStatus(message) {
        const statusEl = document.getElementById("status");
        statusEl.textContent = message;
    }
    async function getEnabledDomains() {
        const raw = await chrome.storage.local.get(STORAGE_KEY);
        return Array.isArray(raw[STORAGE_KEY]) ? raw[STORAGE_KEY] : [];
    }
    async function setEnabledDomains(domains) {
        await chrome.storage.local.set({ [STORAGE_KEY]: domains });
    }
    async function renderDomains() {
        const listEl = document.getElementById("domains");
        listEl.innerHTML = "";
        const domains = await getEnabledDomains();
        if (domains.length === 0) {
            const empty = document.createElement("li");
            empty.textContent = "No enabled domains.";
            listEl.appendChild(empty);
            return;
        }
        domains.sort().forEach((domain) => {
            const item = document.createElement("li");
            item.textContent = domain;
            listEl.appendChild(item);
        });
    }
    async function clearAll() {
        await setEnabledDomains([]);
        await renderDomains();
        setStatus("Cleared all enabled domains.");
    }
    async function initOptions() {
        document.getElementById("clear-all")?.addEventListener("click", () => {
            void clearAll();
        });
        await renderDomains();
    }
    initOptions().catch((error) => {
        setStatus(`Error: ${error.message}`);
    });
})();
