"use strict";
(() => {
    const STORAGE_KEYS = {
        enabled: "imageQuickSaveEnabled"
    };
    async function getEnabledState() {
        const current = await chrome.storage.local.get(STORAGE_KEYS.enabled);
        if (typeof current[STORAGE_KEYS.enabled] === "boolean") {
            return current[STORAGE_KEYS.enabled];
        }
        return true;
    }
    async function setEnabledState(enabled) {
        await chrome.storage.local.set({ [STORAGE_KEYS.enabled]: enabled });
    }
    async function render() {
        const statusEl = document.getElementById("status");
        const toggleBtn = document.getElementById("toggle-enabled");
        const enabled = await getEnabledState();
        statusEl.textContent = enabled
            ? "Hover button is enabled on image elements."
            : "Hover button is disabled.";
        toggleBtn.textContent = enabled ? "Disable hover save button" : "Enable hover save button";
    }
    async function init() {
        const toggleBtn = document.getElementById("toggle-enabled");
        const optionsBtn = document.getElementById("open-options");
        toggleBtn.addEventListener("click", async () => {
            const enabled = await getEnabledState();
            await setEnabledState(!enabled);
            await render();
        });
        optionsBtn.addEventListener("click", () => {
            chrome.runtime.openOptionsPage();
        });
        await render();
    }
    init().catch((error) => {
        const statusEl = document.getElementById("status");
        statusEl.textContent = `Error: ${error.message}`;
    });
})();
