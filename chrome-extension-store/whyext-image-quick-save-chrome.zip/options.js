"use strict";
(() => {
    const STORAGE_KEYS = {
        enabled: "imageQuickSaveEnabled",
        saveAs: "imageQuickSaveSaveAsDialog"
    };
    function setStatus(message) {
        const statusEl = document.getElementById("status");
        statusEl.textContent = message;
    }
    async function loadSettings() {
        const current = await chrome.storage.local.get([STORAGE_KEYS.enabled, STORAGE_KEYS.saveAs]);
        const rawEnabled = current[STORAGE_KEYS.enabled];
        const rawSaveAs = current[STORAGE_KEYS.saveAs];
        return {
            enabled: typeof rawEnabled === "boolean" ? rawEnabled : true,
            saveAs: typeof rawSaveAs === "boolean" ? rawSaveAs : false
        };
    }
    async function saveSettings(next) {
        await chrome.storage.local.set({
            [STORAGE_KEYS.enabled]: next.enabled,
            [STORAGE_KEYS.saveAs]: next.saveAs
        });
    }
    async function render() {
        const enabledEl = document.getElementById("enabled");
        const saveAsEl = document.getElementById("saveAs");
        const settings = await loadSettings();
        enabledEl.checked = settings.enabled;
        saveAsEl.checked = settings.saveAs;
        setStatus("Settings loaded.");
    }
    async function initOptions() {
        const enabledEl = document.getElementById("enabled");
        const saveAsEl = document.getElementById("saveAs");
        const onChange = async () => {
            await saveSettings({
                enabled: enabledEl.checked,
                saveAs: saveAsEl.checked
            });
            setStatus("Saved.");
        };
        enabledEl.addEventListener("change", () => {
            void onChange();
        });
        saveAsEl.addEventListener("change", () => {
            void onChange();
        });
        await render();
    }
    initOptions().catch((error) => {
        setStatus(`Error: ${error.message}`);
    });
})();
